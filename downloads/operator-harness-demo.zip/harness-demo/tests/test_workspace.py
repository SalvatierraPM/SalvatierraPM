from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from operator_harness.workspace import (
    GitChange,
    find_scope_leakage,
    find_stray_documents,
)


class StrayDocumentTests(unittest.TestCase):
    def test_flags_only_unrouted_untracked_documents(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            project = {"artifact_routes": {"project_docs": "docs"}}
            changes = [
                GitChange("??", "random-proposal.pdf"),
                GitChange("??", "docs/decision.md"),
                GitChange("??", "README.md"),
                GitChange("??", "src/app.py"),
                GitChange(" M", "existing-notes.md"),
            ]

            stray = find_stray_documents(root, project, changes)

        self.assertEqual(stray, ["random-proposal.pdf"])

    def test_flags_paths_that_reference_another_registered_project(self) -> None:
        current = {"id": "revenue-pro", "scope_aliases": ["revenue-pro"]}
        projects = [
            current,
            {"id": "ur-trax", "scope_aliases": ["ur-trax", "ur_trax"]},
        ]
        changes = [
            GitChange("??", "supabase/migrations/consolidate_ur_trax_backend.sql")
        ]

        leakage = find_scope_leakage(current, projects, changes)

        self.assertEqual(len(leakage), 1)
        self.assertIn("ur-trax", leakage[0])

    def test_allows_a_declared_path_scoped_project_share(self) -> None:
        current = {
            "id": "revenue-pro",
            "scope_aliases": ["revenue-pro"],
            "scope_shares": [
                {
                    "project_id": "ur-trax",
                    "paths": ["supabase/migrations/*ur_trax*.sql"],
                    "reason": "Temporary shared Supabase project",
                }
            ],
        }
        projects = [
            current,
            {"id": "ur-trax", "scope_aliases": ["ur-trax", "ur_trax"]},
        ]
        changes = [
            GitChange("??", "supabase/migrations/consolidate_ur_trax_backend.sql"),
            GitChange("??", "docs/ur_trax_product_plan.md"),
        ]

        leakage = find_scope_leakage(current, projects, changes)

        self.assertEqual(len(leakage), 1)
        self.assertIn("docs/ur_trax_product_plan.md", leakage[0])


if __name__ == "__main__":
    unittest.main()
