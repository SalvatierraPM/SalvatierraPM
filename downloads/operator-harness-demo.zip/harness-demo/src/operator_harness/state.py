from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .model import HARNESS_ROOT, HarnessConfigError


STATE_ROOT = Path(
    os.environ.get("PABLO_HARNESS_STATE_ROOT", str(HARNESS_ROOT / "state"))
).expanduser()
SECRET_PATTERNS = (
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}"),
    re.compile(r"\bsb_secret_[A-Za-z0-9_-]+"),
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]+"),
    re.compile(r"\bghp_[A-Za-z0-9]{16,}"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._-]{16,}", re.IGNORECASE),
)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_timestamp(value: datetime | None = None) -> str:
    return (value or utc_now()).replace(microsecond=0).isoformat()


def safe_project_id(project_id: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", project_id).strip("-")
    if not normalized:
        raise HarnessConfigError("Project id cannot be converted to a safe state filename")
    return normalized


def checkpoint_path(project_id: str) -> Path:
    return STATE_ROOT / "checkpoints" / f"{safe_project_id(project_id)}.json"


def handoff_directory(project_id: str) -> Path:
    return STATE_ROOT / "handoffs" / safe_project_id(project_id)


def contains_secret_like_text(values: Iterable[str]) -> bool:
    return any(pattern.search(value) for value in values for pattern in SECRET_PATTERNS)


def load_checkpoint(project_id: str) -> dict[str, Any] | None:
    path = checkpoint_path(project_id)
    if not path.exists():
        return None
    try:
        with path.open(encoding="utf-8") as handle:
            payload = json.load(handle)
    except json.JSONDecodeError as exc:
        raise HarnessConfigError(
            f"Invalid checkpoint JSON in {path}: line {exc.lineno}, column {exc.colno}"
        ) from exc
    if not isinstance(payload, dict):
        raise HarnessConfigError(f"Expected checkpoint object in {path}")
    return payload


def _write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def merge_unique(existing: Iterable[str], additions: Iterable[str]) -> list[str]:
    return list(dict.fromkeys([*existing, *additions]))


def build_checkpoint(
    project: dict[str, Any],
    *,
    objective: str,
    completed: Iterable[str] = (),
    decisions: Iterable[str] = (),
    evidence: Iterable[str] = (),
    notes: Iterable[str] = (),
    next_action: str | None = None,
    previous: dict[str, Any] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    previous = previous or {}
    text_values = [
        objective,
        next_action or "",
        *completed,
        *decisions,
        *evidence,
        *notes,
    ]
    if contains_secret_like_text(text_values):
        raise HarnessConfigError(
            "Checkpoint appears to contain a credential or token; store a reference instead"
        )

    timestamp = utc_timestamp(now)
    return {
        "version": 1,
        "project_id": project["id"],
        "project_name": project["name"],
        "organization": project["organization"],
        "identity": project["identity"],
        "status": "active",
        "created_at": previous.get("created_at", timestamp),
        "updated_at": timestamp,
        "objective": objective,
        "completed": merge_unique(previous.get("completed", []), completed),
        "decisions": merge_unique(previous.get("decisions", []), decisions),
        "evidence": merge_unique(previous.get("evidence", []), evidence),
        "notes": merge_unique(previous.get("notes", []), notes),
        "next_action": next_action or previous.get("next_action"),
    }


def write_checkpoint(checkpoint: dict[str, Any]) -> Path:
    path = checkpoint_path(checkpoint["project_id"])
    _write_json_atomic(path, checkpoint)
    return path


def render_handoff(report: dict[str, Any]) -> str:
    project = report["project"]
    checkpoint = report.get("checkpoint") or {}

    def section(title: str, values: Iterable[str]) -> list[str]:
        items = list(values)
        lines = [f"## {title}", ""]
        lines.extend([f"- {item}" for item in items] or ["- None recorded"])
        lines.append("")
        return lines

    lines = [
        f"# Handoff — {project['name']}",
        "",
        f"Generated: {report['generated_at']}",
        f"Project: `{project['id']}`",
        f"Identity: `{project['identity']}`",
        f"Organization: `{project['organization']}`",
        "",
        "## Objective",
        "",
        checkpoint.get("objective") or "No checkpoint objective recorded.",
        "",
    ]
    lines.extend(section("Completed", checkpoint.get("completed", [])))
    lines.extend(section("Decisions", checkpoint.get("decisions", [])))
    lines.extend(section("Evidence", checkpoint.get("evidence", [])))
    lines.extend(section("Notes", checkpoint.get("notes", [])))
    lines.extend(
        [
            "## Next action",
            "",
            checkpoint.get("next_action") or "Not recorded.",
            "",
        ]
    )
    lines.extend(section("Effective gates", report.get("effective_gates", [])))
    lines.extend(section("Workspace changes", report.get("workspace_changes", [])))
    lines.extend(section("Stray document candidates", report.get("stray_documents", [])))
    lines.extend(section("Scope leakage candidates", report.get("scope_leakage", [])))
    lines.extend(section("Writeback proposals", report.get("writeback_proposals", [])))
    lines.extend(
        [
            "## External action status",
            "",
            "No external writeback was executed by this handoff.",
            "",
        ]
    )
    return "\n".join(lines)


def write_handoff(report: dict[str, Any], now: datetime | None = None) -> Path:
    timestamp = (now or utc_now()).strftime("%Y%m%dT%H%M%SZ")
    directory = handoff_directory(report["project"]["id"])
    destination = directory / f"{timestamp}.md"
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".md.tmp")
    temporary.write_text(render_handoff(report), encoding="utf-8")
    temporary.replace(destination)

    checkpoint = report.get("checkpoint")
    if checkpoint:
        closed_checkpoint = {
            **checkpoint,
            "status": "closed",
            "closed_at": utc_timestamp(now),
            "handoff_path": str(destination),
        }
        write_checkpoint(closed_checkpoint)
    return destination
