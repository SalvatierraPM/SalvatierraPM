# Procedencia de la demo

Los módulos Python, el ejecutable de la CLI, los esquemas y las pruebas existentes se copiaron del Operator Harness local de Pablo Moraga el 20 de octubre de 2026. Se excluyeron los registros personales y el estado de las sesiones. El directorio de configuración y el proyecto de ejemplo se crearon para esta revisión y contienen datos ficticios. No hay integraciones externas configuradas.
