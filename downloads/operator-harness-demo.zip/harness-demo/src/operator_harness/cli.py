from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .instructions import (
    apply_instruction_sync,
    plan_instruction_sync,
    plans_as_json,
)
from .model import (
    Finding,
    HarnessConfigError,
    expand_path,
    get_by_id,
    load_configuration,
    merged_gates,
    resolve_project,
    validate_configuration,
    write_project_manifest,
)
from .state import (
    build_checkpoint,
    load_checkpoint,
    utc_timestamp,
    write_checkpoint,
    write_handoff,
)
from .workspace import (
    find_scope_leakage,
    find_stray_documents,
    read_workspace_snapshot,
)


SEVERITY_ORDER = {"error": 0, "warning": 1, "info": 2}


def _project_items(config: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    return config["projects"].get("projects", [])


def _resolve_project_or_exit(
    target: str, config: dict[str, dict[str, Any]]
) -> dict[str, Any] | None:
    project = resolve_project(_project_items(config), target)
    if project is None:
        print(f"No registered project matches: {target}", file=sys.stderr)
    return project


def command_list(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    projects = _project_items(config)
    if args.json:
        print(json.dumps(projects, indent=2, ensure_ascii=False))
        return 0

    print("PROJECTS")
    for project in projects:
        managed = "managed" if project.get("managed", True) else "discovery"
        print(
            f"- {project.get('id')}: {project.get('name')} "
            f"[{project.get('profile')} · L{project.get('level')} · {managed}]"
        )
    return 0


def command_accounts(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    accounts_config = config["accounts"]
    all_accounts = accounts_config.get("accounts", [])
    account_sets = accounts_config.get("account_sets", [])
    project: dict[str, Any] | None = None

    if args.target:
        project = _resolve_project_or_exit(args.target, config)
        if project is None:
            return 2
        selected_set_ids = set(project.get("account_sets", []))
        selected_account_ids = {
            account_id
            for account_set in account_sets
            if account_set.get("id") in selected_set_ids
            for account_id in account_set.get("accounts", [])
        }
        accounts = [
            account for account in all_accounts if account.get("id") in selected_account_ids
        ]
    else:
        accounts = list(all_accounts)

    status_counts: dict[str, int] = {}
    for account in accounts:
        status = account.get("status", "needs_verification")
        status_counts[status] = status_counts.get(status, 0) + 1
    verified = status_counts.get("verified", 0)
    summary = {
        "total": len(accounts),
        "verified": verified,
        "requires_attention": len(accounts) - verified,
        "by_status": status_counts,
    }
    payload = {
        "project": project.get("id") if project else None,
        "summary": summary,
        "accounts": accounts,
    }
    if args.json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    scope = f" · {project['name']}" if project else " · ALL PROJECTS"
    print(f"ACCOUNTS{scope}")
    print(
        f"- verified: {summary['verified']}/{summary['total']}"
        f" · requires attention: {summary['requires_attention']}"
    )
    for account in accounts:
        marker = account.get("status", "needs_verification")
        print(
            f"- [{marker}] {account.get('id')}: {account.get('account_name')}"
            f" · {account.get('platform')} · owner={account.get('owner')}"
        )
    return 0


def _resolved_context(
    project: dict[str, Any], config: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    profiles = config["profiles"].get("profiles", [])
    identities = config["identities"].get("identities", [])
    profile = get_by_id(profiles, project.get("profile", ""))
    identity = get_by_id(identities, project.get("identity", ""))
    return {
        "project": project,
        "identity": identity,
        "profile": profile,
        "effective_gates": merged_gates(project, profile),
        "external_action_policy": config["settings"].get(
            "external_action_policy", "explicit_approval"
        ),
        "checkpoint": load_checkpoint(project["id"]),
    }


def command_open(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    project = _resolve_project_or_exit(args.target, config)
    if project is None:
        return 2

    context = _resolved_context(project, config)
    if args.json:
        print(json.dumps(context, indent=2, ensure_ascii=False))
        return 0

    identity = context["identity"] or {}
    profile = context["profile"] or {}
    print(f"PROJECT: {project.get('name')} ({project.get('id')})")
    print(
        f"MODE: {profile.get('name', project.get('profile'))} · "
        f"LEVEL {project.get('level')} · {project.get('status')}"
    )
    print(
        f"IDENTITY: {identity.get('name', project.get('identity'))} · "
        f"ORGANIZATION: {project.get('organization')}"
    )
    print(f"PRIMARY ROOT: {project.get('primary_root') or 'not assigned'}")
    print(f"ACCOUNT SETS: {', '.join(project.get('account_sets', [])) or 'none'}")
    print(f"EXTERNAL ACTIONS: {context['external_action_policy']}")

    checkpoint = context.get("checkpoint")
    if checkpoint:
        print("CHECKPOINT:")
        print(f"- status: {checkpoint.get('status')}")
        print(f"- objective: {checkpoint.get('objective')}")
        print(f"- next: {checkpoint.get('next_action') or 'not recorded'}")
        print(f"- updated: {checkpoint.get('updated_at')}")
    else:
        print("CHECKPOINT: none")

    print("SOURCES OF TRUTH:")
    for source in project.get("sources_of_truth", []):
        print(f"- {source.get('name')}: {source.get('location')}")

    print("ARTIFACT ROUTES:")
    for artifact_type, destination in project.get("artifact_routes", {}).items():
        print(f"- {artifact_type}: {destination}")

    print("EFFECTIVE GATES:")
    for gate in context["effective_gates"]:
        print(f"- {gate}")
    return 0


def command_checkpoint(
    args: argparse.Namespace, config: dict[str, dict[str, Any]]
) -> int:
    project = _resolve_project_or_exit(args.target, config)
    if project is None:
        return 2

    previous = load_checkpoint(project["id"])
    objective = args.objective or (previous or {}).get("objective")
    if not objective:
        print("Checkpoint requires --objective the first time", file=sys.stderr)
        return 2

    checkpoint = build_checkpoint(
        project,
        objective=objective,
        completed=args.completed,
        decisions=args.decision,
        evidence=args.evidence,
        notes=args.note,
        next_action=args.next_action,
        previous=previous,
    )
    destination = write_checkpoint(checkpoint)
    if args.json:
        print(json.dumps(checkpoint, indent=2, ensure_ascii=False))
    else:
        print(f"CHECKPOINT SAVED: {project['name']}")
        print(f"- objective: {checkpoint['objective']}")
        print(f"- completed: {len(checkpoint['completed'])}")
        print(f"- next: {checkpoint.get('next_action') or 'not recorded'}")
        print(f"- path: {destination}")
    return 0


def _writeback_proposals(project: dict[str, Any]) -> list[str]:
    route_terms = (
        "decision",
        "handoff",
        "session",
        "commitment",
        "relationship",
    )
    return [
        f"{artifact_type} -> {destination} (proposal only)"
        for artifact_type, destination in project.get("artifact_routes", {}).items()
        if any(term in artifact_type for term in route_terms)
    ]


def _close_report(
    project: dict[str, Any], config: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    context = _resolved_context(project, config)
    primary_root_value = project.get("primary_root")
    if not primary_root_value:
        raise HarnessConfigError(f"Project has no primary root: {project['id']}")
    primary_root = expand_path(primary_root_value)
    snapshot = read_workspace_snapshot(primary_root)
    workspace_changes = [change.display() for change in snapshot.changes]
    if snapshot.warning:
        workspace_changes.insert(0, f"WARNING: {snapshot.warning}")
    stray_documents = find_stray_documents(primary_root, project, snapshot.changes)
    scope_leakage = find_scope_leakage(
        project, _project_items(config), snapshot.changes
    )
    return {
        "version": 1,
        "generated_at": utc_timestamp(),
        "project": project,
        "checkpoint": context.get("checkpoint"),
        "effective_gates": context["effective_gates"],
        "workspace_changes": workspace_changes,
        "stray_documents": stray_documents,
        "scope_leakage": scope_leakage,
        "writeback_proposals": _writeback_proposals(project),
        "external_writebacks_executed": False,
    }


def command_close(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    project = _resolve_project_or_exit(args.target, config)
    if project is None:
        return 2
    report = _close_report(project, config)

    handoff_path: Path | None = None
    if args.write:
        if not report.get("checkpoint"):
            print(
                "A checkpoint is required before saving a handoff. "
                "Run harness checkpoint first.",
                file=sys.stderr,
            )
            return 2
        handoff_path = write_handoff(report)

    if args.json:
        payload = {**report, "handoff_path": str(handoff_path) if handoff_path else None}
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        checkpoint = report.get("checkpoint") or {}
        print(f"CLOSE {'SAVED' if handoff_path else 'PREVIEW'}: {project['name']}")
        print(f"- objective: {checkpoint.get('objective') or 'no checkpoint'}")
        print(f"- next: {checkpoint.get('next_action') or 'not recorded'}")
        print(f"- workspace changes: {len(report['workspace_changes'])}")
        print(f"- stray document candidates: {len(report['stray_documents'])}")
        for path in report["stray_documents"]:
            print(f"  - {path}")
        print(f"- scope leakage candidates: {len(report['scope_leakage'])}")
        for candidate in report["scope_leakage"]:
            print(f"  - {candidate}")
        print(f"- effective gates to review: {len(report['effective_gates'])}")
        print(f"- writeback proposals: {len(report['writeback_proposals'])}")
        for proposal in report["writeback_proposals"]:
            print(f"  - {proposal}")
        print("- external writebacks executed: no")
        if handoff_path:
            print(f"- handoff: {handoff_path}")
        else:
            print("- use --write to save the local handoff")

    if args.strict and (report["stray_documents"] or report["scope_leakage"]):
        return 1
    return 0


def command_sync(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    project = _resolve_project_or_exit(args.target, config)
    if project is None:
        return 2
    primary_root_value = project.get("primary_root")
    if not primary_root_value:
        print(f"Project has no primary root: {project['id']}", file=sys.stderr)
        return 2

    profile = get_by_id(
        config["profiles"].get("profiles", []), project.get("profile", "")
    )
    plans = plan_instruction_sync(expand_path(primary_root_value), project, profile)
    if args.write:
        apply_instruction_sync(plans)

    if args.json:
        print(plans_as_json(plans))
    else:
        print(f"INSTRUCTION SYNC {'APPLIED' if args.write else 'PREVIEW'}: {project['name']}")
        for plan in plans:
            print(f"- {plan.status}: {plan.path}")
            if args.show_content:
                print(plan.content)
    return 0


def command_doctor(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    findings = validate_configuration(config)
    for project in _project_items(config):
        primary_root_value = project.get("primary_root")
        if not project.get("managed", True) or not primary_root_value:
            continue
        profile = get_by_id(
            config["profiles"].get("profiles", []), project.get("profile", "")
        )
        for plan in plan_instruction_sync(
            expand_path(primary_root_value), project, profile
        ):
            if plan.status == "update_managed":
                findings.append(
                    Finding(
                        "warning",
                        "instruction_drift",
                        "Harness-managed instruction file is out of sync",
                        project.get("id"),
                        str(plan.path),
                    )
                )
            elif plan.status == "blocked_unmanaged":
                findings.append(
                    Finding(
                        "warning",
                        "instruction_unmanaged",
                        "Instruction file exists but is not harness-managed",
                        project.get("id"),
                        str(plan.path),
                    )
                )
    if args.project:
        findings = [
            finding
            for finding in findings
            if finding.project_id in (None, args.project)
        ]

    findings.sort(key=lambda item: (SEVERITY_ORDER.get(item.severity, 9), item.code))
    if args.json:
        payload = {
            "ok": not any(item.severity == "error" for item in findings),
            "counts": {
                severity: sum(1 for item in findings if item.severity == severity)
                for severity in ("error", "warning", "info")
            },
            "findings": [item.as_dict() for item in findings],
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        errors = sum(1 for item in findings if item.severity == "error")
        warnings = sum(1 for item in findings if item.severity == "warning")
        print(f"HARNESS DOCTOR: {errors} errors · {warnings} warnings")
        for finding in findings:
            scope = f" [{finding.project_id}]" if finding.project_id else ""
            location = f" ({finding.path})" if finding.path else ""
            print(
                f"- {finding.severity.upper()}{scope} {finding.code}: "
                f"{finding.message}{location}"
            )

    return 1 if any(item.severity == "error" for item in findings) else 0


def command_init(args: argparse.Namespace, config: dict[str, dict[str, Any]]) -> int:
    project_root = expand_path(args.path)
    if not project_root.exists() or not project_root.is_dir():
        print(f"Project directory does not exist: {project_root}", file=sys.stderr)
        return 2

    valid_profiles = {
        profile.get("id") for profile in config["profiles"].get("profiles", [])
    }
    valid_identities = {
        identity.get("id") for identity in config["identities"].get("identities", [])
    }
    if args.profile not in valid_profiles:
        print(f"Unknown profile: {args.profile}", file=sys.stderr)
        return 2
    if args.identity not in valid_identities:
        print(f"Unknown identity: {args.identity}", file=sys.stderr)
        return 2

    manifest = {
        "$schema": str(
            config["settings"].get(
                "project_manifest_schema",
                "schemas/project-manifest.schema.json",
            )
        ),
        "version": 1,
        "id": args.id,
        "name": args.name,
        "organization": args.organization,
        "identity": args.identity,
        "profile": args.profile,
        "level": args.level,
        "external_actions": "explicit_approval",
        "artifact_routes": {
            "code": ".",
            "project_docs": "docs/",
            "scratch": ".harness/tmp/",
        },
    }
    try:
        destination = write_project_manifest(project_root, manifest, force=args.force)
    except FileExistsError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    print(f"Created manifest: {destination}")
    print("Registry was not modified. Review the manifest before registration.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="harness",
        description="Identity-aware control plane for Pablo's project portfolio",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list", help="List registered projects")
    list_parser.add_argument("--json", action="store_true")
    list_parser.set_defaults(handler=command_list)

    accounts_parser = subparsers.add_parser(
        "accounts", help="Show the master account inventory"
    )
    accounts_parser.add_argument("target", nargs="?")
    accounts_parser.add_argument("--json", action="store_true")
    accounts_parser.set_defaults(handler=command_accounts)

    open_parser = subparsers.add_parser("open", help="Resolve and display a project context")
    open_parser.add_argument("target", nargs="?", default=".")
    open_parser.add_argument("--json", action="store_true")
    open_parser.set_defaults(handler=command_open)

    checkpoint_parser = subparsers.add_parser(
        "checkpoint", help="Save resumable local project state"
    )
    checkpoint_parser.add_argument("target", nargs="?", default=".")
    checkpoint_parser.add_argument("--objective")
    checkpoint_parser.add_argument("--completed", action="append", default=[])
    checkpoint_parser.add_argument("--decision", action="append", default=[])
    checkpoint_parser.add_argument("--evidence", action="append", default=[])
    checkpoint_parser.add_argument("--note", action="append", default=[])
    checkpoint_parser.add_argument("--next", dest="next_action")
    checkpoint_parser.add_argument("--json", action="store_true")
    checkpoint_parser.set_defaults(handler=command_checkpoint)

    close_parser = subparsers.add_parser(
        "close", help="Preview or save a local project handoff"
    )
    close_parser.add_argument("target", nargs="?", default=".")
    close_parser.add_argument("--write", action="store_true")
    close_parser.add_argument("--strict", action="store_true")
    close_parser.add_argument("--json", action="store_true")
    close_parser.set_defaults(handler=command_close)

    sync_parser = subparsers.add_parser(
        "sync", help="Preview or apply generated AGENTS.md and CLAUDE.md"
    )
    sync_parser.add_argument("target", nargs="?", default=".")
    sync_parser.add_argument("--write", action="store_true")
    sync_parser.add_argument("--show-content", action="store_true")
    sync_parser.add_argument("--json", action="store_true")
    sync_parser.set_defaults(handler=command_sync)

    doctor_parser = subparsers.add_parser("doctor", help="Audit harness health and drift")
    doctor_parser.add_argument("--project")
    doctor_parser.add_argument("--json", action="store_true")
    doctor_parser.set_defaults(handler=command_doctor)

    init_parser = subparsers.add_parser("init", help="Create a project-local harness manifest")
    init_parser.add_argument("path", nargs="?", default=".")
    init_parser.add_argument("--id", required=True)
    init_parser.add_argument("--name", required=True)
    init_parser.add_argument("--profile", required=True)
    init_parser.add_argument("--organization", required=True)
    init_parser.add_argument("--identity", required=True)
    init_parser.add_argument("--level", type=int, choices=range(0, 4), required=True)
    init_parser.add_argument("--force", action="store_true")
    init_parser.set_defaults(handler=command_init)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        config = load_configuration()
    except HarnessConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    try:
        return args.handler(args, config)
    except (HarnessConfigError, FileExistsError) as exc:
        print(f"Harness error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
