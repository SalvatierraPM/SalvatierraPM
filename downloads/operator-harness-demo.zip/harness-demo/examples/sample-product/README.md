# Sample Product

A fictional project used to demonstrate context resolution and local handoffs.
