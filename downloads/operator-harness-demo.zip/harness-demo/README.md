# Operator Harness — demo ejecutable

**Contexto de proyecto y continuidad entre sesiones para el desarrollo asistido por IA.**

Esta copia para revisión contiene el núcleo del Harness y un proyecto ficticio de ejemplo. Excluye registros de cuentas personales, documentos de clientes, credenciales y estado de sesiones operativas.

Requiere Python 3.11 o posterior. El núcleo utiliza únicamente la biblioteca estándar de Python.

## Ejecutar

Descomprime el paquete, entra en su directorio raíz y ejecuta:

```sh
export HARNESS_DEMO_ROOT="$PWD"
export PYTHONPATH="$PWD/src"
python3 -m operator_harness.cli list
python3 -m operator_harness.cli open demo.product
python3 -m operator_harness.cli doctor
```

## Probar la continuidad entre sesiones

```sh
python3 -m operator_harness.cli checkpoint demo.product \
  --objective "Revisar el producto de ejemplo" \
  --completed "Contexto del proyecto resuelto" \
  --next "Revisar el traspaso"
python3 -m operator_harness.cli close demo.product
```

El punto de control se guarda únicamente en el directorio `state/` de esta demo extraída. `close` previsualiza el traspaso; añade `--write` para guardarlo localmente. Las capturas del estado del entorno utilizan Git cuando está disponible; una carpeta extraída sin metadatos de Git puede indicar esa limitación.

## Ejecutar las pruebas

```sh
python3 -m unittest discover -s tests -v
```

Las 14 pruebas existentes aprobaron el 20 de octubre de 2026. El comando `doctor` de la demo no detectó errores ni avisos. También se verificaron localmente la resolución del proyecto, la creación de un punto de control y el guardado de un traspaso.

## Mapa del código

| Archivo | Responsabilidad |
| --- | --- |
| `src/operator_harness/model.py` | Carga de registros, resolución de contexto y validación de configuración y manifiestos. |
| `src/operator_harness/cli.py` | Comandos de proyectos, cuentas, puntos de control, traspasos y comprobación de estado. |
| `src/operator_harness/instructions.py` | Previsualización y actualización controlada de archivos de instrucciones gestionados. |
| `src/operator_harness/state.py` | Puntos de control y traspasos locales. |
| `src/operator_harness/workspace.py` | Inspección del entorno y comprobación de límites entre proyectos. |
| `config/` | Registros ficticios de ejemplo. |

El Harness proporciona contexto y controles deterministas para los agentes. Esta demo no ejecuta un LLM ni configura integraciones externas activas.

[Procedencia de la demo](PROVENANCE.md)

Pablo Moraga · Dasein Futures
