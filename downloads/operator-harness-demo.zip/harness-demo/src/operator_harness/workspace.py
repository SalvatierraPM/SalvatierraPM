from __future__ import annotations

from fnmatch import fnmatch
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


DOCUMENT_EXTENSIONS = {
    ".csv",
    ".docx",
    ".html",
    ".md",
    ".pdf",
    ".pptx",
    ".txt",
    ".xlsx",
}
CANONICAL_ROOT_DOCUMENTS = {
    "AGENTS.md",
    "CLAUDE.md",
    "CODE_OF_CONDUCT.md",
    "CONTRIBUTING.md",
    "LICENSE",
    "LICENSE.md",
    "README.md",
    "SECURITY.md",
}


@dataclass(frozen=True)
class GitChange:
    status: str
    path: str

    def display(self) -> str:
        return f"{self.status} {self.path}"


@dataclass(frozen=True)
class WorkspaceSnapshot:
    changes: tuple[GitChange, ...]
    warning: str | None = None


def read_workspace_snapshot(root: Path, timeout_seconds: int = 4) -> WorkspaceSnapshot:
    if not (root / ".git").exists():
        return WorkspaceSnapshot((), "Primary root is not a Git working tree")
    try:
        result = subprocess.run(
            [
                "git",
                "-C",
                str(root),
                "status",
                "--porcelain=v1",
                "-z",
                "--untracked-files=all",
            ],
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return WorkspaceSnapshot((), f"Git status timed out after {timeout_seconds}s")

    if result.returncode != 0:
        stderr = result.stderr.decode("utf-8", errors="replace").strip()
        return WorkspaceSnapshot((), stderr or "Git status failed")

    changes: list[GitChange] = []
    records = result.stdout.decode("utf-8", errors="replace").split("\0")
    skip_next = False
    for record in records:
        if not record:
            continue
        if skip_next:
            skip_next = False
            continue
        status = record[:2]
        path = record[3:] if len(record) > 3 else ""
        changes.append(GitChange(status, path))
        if "R" in status or "C" in status:
            skip_next = True
    return WorkspaceSnapshot(tuple(changes))


def _allowed_route_prefixes(root: Path, project: dict[str, Any]) -> tuple[Path, ...]:
    prefixes = [root / ".harness", root / ".github", root / "docs"]
    for destination in project.get("artifact_routes", {}).values():
        candidate = Path(destination)
        if candidate.is_absolute() or destination == ".":
            continue
        resolved = (root / candidate).resolve(strict=False)
        try:
            resolved.relative_to(root.resolve(strict=False))
        except ValueError:
            continue
        prefixes.append(resolved)
    return tuple(prefixes)


def find_stray_documents(
    root: Path,
    project: dict[str, Any],
    changes: Iterable[GitChange],
) -> list[str]:
    root_resolved = root.resolve(strict=False)
    allowed_prefixes = _allowed_route_prefixes(root_resolved, project)
    stray: list[str] = []

    for change in changes:
        if change.status != "??":
            continue
        relative = Path(change.path)
        if relative.name in CANONICAL_ROOT_DOCUMENTS:
            continue
        if relative.suffix.lower() not in DOCUMENT_EXTENSIONS:
            continue
        absolute = (root_resolved / relative).resolve(strict=False)
        if any(absolute == prefix or absolute.is_relative_to(prefix) for prefix in allowed_prefixes):
            continue
        stray.append(change.path)
    return sorted(stray)


def find_scope_leakage(
    current_project: dict[str, Any],
    all_projects: Iterable[dict[str, Any]],
    changes: Iterable[GitChange],
) -> list[str]:
    leakage: list[str] = []
    for change in changes:
        normalized_path = change.path.lower()
        for other_project in all_projects:
            if other_project.get("id") == current_project.get("id"):
                continue
            aliases = {
                alias.lower()
                for alias in other_project.get("scope_aliases", [])
                if len(alias) >= 4
            }
            matched_alias = next(
                (alias for alias in sorted(aliases, key=len, reverse=True) if alias in normalized_path),
                None,
            )
            if matched_alias:
                declared_share = next(
                    (
                        share
                        for share in current_project.get("scope_shares", [])
                        if share.get("project_id") == other_project.get("id")
                        and any(
                            fnmatch(change.path, pattern)
                            for pattern in share.get("paths", [])
                        )
                    ),
                    None,
                )
                if declared_share:
                    continue
                leakage.append(
                    f"{change.path} -> references {other_project.get('id')} "
                    f"via alias '{matched_alias}'"
                )
                break
    return sorted(set(leakage))
