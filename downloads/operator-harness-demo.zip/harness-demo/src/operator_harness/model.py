from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


HARNESS_ROOT = Path(__file__).resolve().parents[2]
CONFIG_ROOT = HARNESS_ROOT / "config"


class HarnessConfigError(ValueError):
    """Raised when harness configuration is invalid."""


@dataclass(frozen=True)
class Finding:
    severity: str
    code: str
    message: str
    project_id: str | None = None
    path: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "project_id": self.project_id,
            "path": self.path,
        }


def load_json(path: Path) -> dict[str, Any]:
    try:
        with path.open(encoding="utf-8") as handle:
            payload = json.load(handle)
    except FileNotFoundError as exc:
        raise HarnessConfigError(f"Missing configuration file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise HarnessConfigError(
            f"Invalid JSON in {path}: line {exc.lineno}, column {exc.colno}"
        ) from exc

    if not isinstance(payload, dict):
        raise HarnessConfigError(f"Expected JSON object in {path}")
    return payload


def load_configuration() -> dict[str, dict[str, Any]]:
    return {
        "settings": load_json(CONFIG_ROOT / "settings.json"),
        "profiles": load_json(CONFIG_ROOT / "profiles.json"),
        "identities": load_json(CONFIG_ROOT / "identities.json"),
        "accounts": load_json(CONFIG_ROOT / "accounts.json"),
        "projects": load_json(CONFIG_ROOT / "projects.json"),
    }


def expand_path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve(strict=False)


def project_roots(project: dict[str, Any]) -> list[Path]:
    return [expand_path(value) for value in project.get("roots", []) if value]


def _is_within(candidate: Path, root: Path) -> bool:
    try:
        candidate.relative_to(root)
        return True
    except ValueError:
        return False


def resolve_project(
    projects: Iterable[dict[str, Any]], target: str | Path
) -> dict[str, Any] | None:
    target_text = str(target)
    for project in projects:
        if project.get("id") == target_text:
            return project

    candidate = expand_path(target_text)
    matches: list[tuple[int, dict[str, Any]]] = []
    for project in projects:
        for root in project_roots(project):
            if candidate == root or _is_within(candidate, root):
                matches.append((len(str(root)), project))

    if not matches:
        return None
    return max(matches, key=lambda item: item[0])[1]


def get_by_id(items: Iterable[dict[str, Any]], item_id: str) -> dict[str, Any] | None:
    return next((item for item in items if item.get("id") == item_id), None)


def _duplicate_ids(items: Iterable[dict[str, Any]]) -> set[str]:
    seen: set[str] = set()
    duplicates: set[str] = set()
    for item in items:
        item_id = item.get("id")
        if not item_id:
            continue
        if item_id in seen:
            duplicates.add(item_id)
        seen.add(item_id)
    return duplicates


def validate_configuration(config: dict[str, dict[str, Any]]) -> list[Finding]:
    findings: list[Finding] = []
    profiles = config["profiles"].get("profiles", [])
    identities = config["identities"].get("identities", [])
    accounts = config["accounts"].get("accounts", [])
    account_sets = config["accounts"].get("account_sets", [])
    projects = config["projects"].get("projects", [])

    collections = {
        "profile": profiles,
        "identity": identities,
        "account": accounts,
        "account_set": account_sets,
        "project": projects,
    }
    for collection_name, items in collections.items():
        for duplicate in sorted(_duplicate_ids(items)):
            findings.append(
                Finding(
                    "error",
                    "duplicate_id",
                    f"Duplicate {collection_name} id: {duplicate}",
                )
            )

    profile_ids = {item.get("id") for item in profiles}
    identity_ids = {item.get("id") for item in identities}
    account_ids = {item.get("id") for item in accounts}
    account_set_ids = {item.get("id") for item in account_sets}
    project_ids = {item.get("id") for item in projects}

    for account_set in account_sets:
        for account_id in account_set.get("accounts", []):
            if account_id not in account_ids:
                findings.append(
                    Finding(
                        "error",
                        "unknown_account",
                        f"Account set {account_set.get('id')} references {account_id}",
                    )
                )

    for project in projects:
        project_id = project.get("id")
        if not project_id:
            findings.append(Finding("error", "missing_project_id", "Project has no id"))
            continue

        if project.get("profile") not in profile_ids:
            findings.append(
                Finding(
                    "error",
                    "unknown_profile",
                    f"Unknown profile: {project.get('profile')}",
                    project_id,
                )
            )
        if project.get("identity") not in identity_ids:
            findings.append(
                Finding(
                    "error",
                    "unknown_identity",
                    f"Unknown identity: {project.get('identity')}",
                    project_id,
                )
            )
        for account_set_id in project.get("account_sets", []):
            if account_set_id not in account_set_ids:
                findings.append(
                    Finding(
                        "error",
                        "unknown_account_set",
                        f"Unknown account set: {account_set_id}",
                        project_id,
                    )
                )

        for share in project.get("scope_shares", []):
            shared_project_id = share.get("project_id")
            if shared_project_id not in project_ids:
                findings.append(
                    Finding(
                        "error",
                        "unknown_scope_share_project",
                        f"Unknown shared-scope project: {shared_project_id}",
                        project_id,
                    )
                )
            if not share.get("paths") or not share.get("reason"):
                findings.append(
                    Finding(
                        "error",
                        "invalid_scope_share",
                        "Scope share requires non-empty paths and reason",
                        project_id,
                    )
                )

        if project.get("managed", True):
            roots = project_roots(project)
            if not roots:
                findings.append(
                    Finding(
                        "error",
                        "missing_root",
                        "Managed project has no registered roots",
                        project_id,
                    )
                )
            for root in roots:
                if not root.exists():
                    findings.append(
                        Finding(
                            "error",
                            "root_not_found",
                            "Registered project root does not exist",
                            project_id,
                            str(root),
                        )
                    )

            primary_root = project.get("primary_root")
            if primary_root:
                primary_path = expand_path(primary_root)
                if not any(primary_path == root for root in roots):
                    findings.append(
                        Finding(
                            "warning",
                            "primary_root_not_registered",
                            "Primary root is not present in roots",
                            project_id,
                            str(primary_path),
                        )
                    )
                if primary_path.exists():
                    if not (primary_path / "AGENTS.md").exists():
                        findings.append(
                            Finding(
                                "warning",
                                "agents_missing",
                                "Primary root has no AGENTS.md",
                                project_id,
                                str(primary_path),
                            )
                        )
                    if not (primary_path / "CLAUDE.md").exists():
                        findings.append(
                            Finding(
                                "warning",
                                "claude_missing",
                                "Primary root has no CLAUDE.md",
                                project_id,
                                str(primary_path),
                            )
                        )
                    manifest_path = primary_path / ".harness" / "project.json"
                    if not manifest_path.exists():
                        findings.append(
                            Finding(
                                "warning",
                                "manifest_missing",
                                "Primary root has no .harness/project.json",
                                project_id,
                                str(primary_path),
                            )
                        )
                    else:
                        findings.extend(validate_project_manifest(project, manifest_path))

    for account in accounts:
        if account.get("status") != "verified":
            status = account.get("status", "needs_verification")
            findings.append(
                Finding(
                    "warning",
                    "account_unverified",
                    (
                        f"Account requires attention ({status}): "
                        f"{account.get('id')}"
                    ),
                )
            )
        if any(key in account for key in ("password", "token", "api_key", "secret")):
            findings.append(
                Finding(
                    "error",
                    "secret_field_forbidden",
                    f"Forbidden secret-like field in account: {account.get('id')}",
                )
            )
        if account.get("operational_status") in {
            "credential_rotation_required",
            "inactive",
        }:
            findings.append(
                Finding(
                    "warning",
                    "account_operational_attention",
                    (
                        f"Account is verified but needs operational attention "
                        f"({account.get('operational_status')}): {account.get('id')}"
                    ),
                )
            )

    if any(project.get("organization") == "dasein" for project in projects):
        findings.extend(validate_dasein_adapter())

    return findings


def validate_project_manifest(
    project: dict[str, Any], manifest_path: Path
) -> list[Finding]:
    findings: list[Finding] = []
    project_id = project.get("id")
    try:
        manifest = load_json(manifest_path)
    except HarnessConfigError as exc:
        return [
            Finding(
                "error",
                "manifest_invalid_json",
                str(exc),
                project_id,
                str(manifest_path),
            )
        ]

    required_fields = {
        "version",
        "id",
        "name",
        "organization",
        "identity",
        "profile",
        "level",
        "external_actions",
        "artifact_routes",
    }
    missing_fields = sorted(required_fields - manifest.keys())
    for field_name in missing_fields:
        findings.append(
            Finding(
                "error",
                "manifest_field_missing",
                f"Project manifest is missing required field: {field_name}",
                project_id,
                str(manifest_path),
            )
        )

    for field_name in ("id", "organization", "identity", "profile", "level"):
        if field_name in manifest and manifest.get(field_name) != project.get(field_name):
            findings.append(
                Finding(
                    "error",
                    "manifest_registry_drift",
                    (
                        f"Manifest {field_name}={manifest.get(field_name)!r} does not match "
                        f"registry value {project.get(field_name)!r}"
                    ),
                    project_id,
                    str(manifest_path),
                )
            )

    if manifest.get("external_actions") not in {
        "explicit_approval",
        "draft_only",
        "disabled",
    }:
        findings.append(
            Finding(
                "error",
                "manifest_action_policy_invalid",
                "Manifest external_actions policy is invalid",
                project_id,
                str(manifest_path),
            )
        )

    routes = manifest.get("artifact_routes")
    if routes is not None and (
        not isinstance(routes, dict)
        or any(not isinstance(value, str) for value in routes.values())
    ):
        findings.append(
            Finding(
                "error",
                "manifest_routes_invalid",
                "Manifest artifact_routes must map names to string destinations",
                project_id,
                str(manifest_path),
            )
        )

    forbidden_keys = {"password", "token", "api_key", "secret"}

    def walk(value: Any) -> bool:
        if isinstance(value, dict):
            if forbidden_keys.intersection(value.keys()):
                return True
            return any(walk(item) for item in value.values())
        if isinstance(value, list):
            return any(walk(item) for item in value)
        return False

    if walk(manifest):
        findings.append(
            Finding(
                "error",
                "manifest_secret_field_forbidden",
                "Project manifest contains a forbidden secret-like field",
                project_id,
                str(manifest_path),
            )
        )

    return findings


def validate_dasein_adapter() -> list[Finding]:
    findings: list[Finding] = []
    state_path = Path.home() / ".dasein-state.yaml"
    if state_path.exists():
        age_days = (
            datetime.now(timezone.utc)
            - datetime.fromtimestamp(state_path.stat().st_mtime, timezone.utc)
        ).days
        state_text = state_path.read_text(encoding="utf-8", errors="replace").lower()
        if age_days > 14:
            findings.append(
                Finding(
                    "warning",
                    "dasein_state_stale",
                    f"Dasein strategic state is {age_days} days old",
                    "dasein.innovo-usach",
                    str(state_path),
                )
            )
        if 'outreach_mode: "activo"' in state_text and "outreach pausado" in state_text:
            findings.append(
                Finding(
                    "warning",
                    "dasein_state_conflict",
                    "Dasein state says outreach is active while its context says paused",
                    "dasein.innovo-usach",
                    str(state_path),
                )
            )
    else:
        findings.append(
            Finding(
                "warning",
                "dasein_state_missing",
                "Dasein strategic state file was not found",
            )
        )

    validator = Path.home() / "tools/dasein-agent-compat/dasein_agent_compat.py"
    if not validator.exists():
        findings.append(
            Finding(
                "warning",
                "dasein_compat_missing",
                "Dasein dual-agent validator was not found",
                path=str(validator),
            )
        )
        return findings

    try:
        result = subprocess.run(
            ["python3", str(validator), "validate"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        payload = json.loads(result.stdout)
        if not payload.get("ok", False):
            issues = ", ".join(payload.get("issues", [])) or "unknown issue"
            findings.append(
                Finding(
                    "warning",
                    "dasein_compat_failed",
                    f"Dasein dual-agent validation failed: {issues}",
                    path=str(validator),
                )
            )
    except (subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
        findings.append(
            Finding(
                "warning",
                "dasein_compat_unreadable",
                f"Could not obtain Dasein compatibility status: {exc}",
                path=str(validator),
            )
        )

    return findings


def merged_gates(
    project: dict[str, Any], profile: dict[str, Any] | None
) -> list[str]:
    values = [*(profile or {}).get("gates", []), *project.get("gates", [])]
    return list(dict.fromkeys(values))


def write_project_manifest(
    project_root: Path, manifest: dict[str, Any], force: bool = False
) -> Path:
    destination = project_root / ".harness" / "project.json"
    if destination.exists() and not force:
        raise FileExistsError(f"Manifest already exists: {destination}")

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(destination)
    return destination
