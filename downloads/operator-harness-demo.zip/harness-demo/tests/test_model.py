from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from operator_harness.model import (
    resolve_project,
    validate_configuration,
    validate_project_manifest,
    write_project_manifest,
)


class ResolveProjectTests(unittest.TestCase):
    def test_uses_deepest_matching_root(self) -> None:
        projects = [
            {"id": "parent", "roots": ["/tmp/work"]},
            {"id": "child", "roots": ["/tmp/work/client"]},
        ]

        resolved = resolve_project(projects, "/tmp/work/client/src")

        self.assertIsNotNone(resolved)
        self.assertEqual(resolved["id"], "child")

    def test_resolves_project_id_without_touching_filesystem(self) -> None:
        projects = [{"id": "known", "roots": []}]

        resolved = resolve_project(projects, "known")

        self.assertEqual(resolved, projects[0])


class ValidationTests(unittest.TestCase):
    def test_detects_unknown_account_set(self) -> None:
        config = {
            "settings": {},
            "profiles": {"profiles": [{"id": "profile"}]},
            "identities": {"identities": [{"id": "identity"}]},
            "accounts": {"accounts": [], "account_sets": []},
            "projects": {
                "projects": [
                    {
                        "id": "project",
                        "profile": "profile",
                        "identity": "identity",
                        "organization": "personal",
                        "account_sets": ["missing"],
                        "managed": False,
                    }
                ]
            },
        }

        findings = validate_configuration(config)

        self.assertIn("unknown_account_set", {item.code for item in findings})

    def test_detects_unknown_scope_share_project(self) -> None:
        config = {
            "settings": {},
            "profiles": {"profiles": [{"id": "profile"}]},
            "identities": {"identities": [{"id": "identity"}]},
            "accounts": {"accounts": [], "account_sets": []},
            "projects": {
                "projects": [
                    {
                        "id": "project",
                        "profile": "profile",
                        "identity": "identity",
                        "organization": "personal",
                        "account_sets": [],
                        "managed": False,
                        "scope_shares": [
                            {
                                "project_id": "missing",
                                "paths": ["shared/**"],
                                "reason": "Shared infrastructure",
                            }
                        ],
                    }
                ]
            },
        }

        findings = validate_configuration(config)

        self.assertIn(
            "unknown_scope_share_project", {item.code for item in findings}
        )


class ManifestTests(unittest.TestCase):
    def test_refuses_to_overwrite_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            manifest = {"version": 1, "id": "example"}
            write_project_manifest(root, manifest)

            with self.assertRaises(FileExistsError):
                write_project_manifest(root, manifest)

    def test_detects_manifest_registry_drift(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            manifest_path = Path(temporary_directory) / "project.json"
            manifest_path.write_text(
                """{
                  "version": 1,
                  "id": "wrong-id",
                  "name": "Example",
                  "organization": "personal",
                  "identity": "pablo.personal",
                  "profile": "personal-product",
                  "level": 1,
                  "external_actions": "explicit_approval",
                  "artifact_routes": {}
                }""",
                encoding="utf-8",
            )

            findings = validate_project_manifest(
                {
                    "id": "expected-id",
                    "organization": "personal",
                    "identity": "pablo.personal",
                    "profile": "personal-product",
                    "level": 1,
                },
                manifest_path,
            )

            self.assertIn("manifest_registry_drift", {item.code for item in findings})


if __name__ == "__main__":
    unittest.main()
