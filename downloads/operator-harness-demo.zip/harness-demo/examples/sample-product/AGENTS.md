<!-- operator-harness:managed:v1 -->
# Sample Product — Agent Instructions

This file is generated from the Pablo Operator Harness. Keep project-specific
policy in the harness registry and regenerate this file instead of editing the
managed content by hand.

## Active contract

- Project: `demo.product`
- Organization: `demo`
- Identity: `demo.builder`
- Profile: `demo-product`
- Rigor level: `1`
- External actions: explicit approval required

Start non-trivial work with `harness open .`. Use `harness checkpoint .`
with an objective and next action during meaningful transitions, then run
`harness close .` before handing off.

## Sources of truth

- Sample product repository: `$HARNESS_DEMO_ROOT/examples/sample-product`

## Artifact routes

- `code` → `.`
- `project_docs` → `docs`

## Required gates

- test_before_release
- review_changes_before_publication
- verify_user_workflow

## Safety

- Never store credentials or tokens in repository files or checkpoints.
- Preserve existing user work and unrelated working-tree changes.
- Do not send, publish, deploy, push, or mutate external systems without
  explicit approval for that specific action.
- Treat live code and services as newer than registry notes when they conflict;
  report the drift and verify before acting.
