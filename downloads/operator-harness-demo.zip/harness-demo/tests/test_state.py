from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from operator_harness.model import HarnessConfigError
from operator_harness.state import (
    build_checkpoint,
    load_checkpoint,
    write_checkpoint,
    write_handoff,
)


PROJECT = {
    "id": "example.project",
    "name": "Example Project",
    "organization": "personal",
    "identity": "pablo.personal",
}


class CheckpointTests(unittest.TestCase):
    def test_checkpoint_round_trip(self) -> None:
        now = datetime(2026, 7, 21, 12, 0, tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as temporary_directory:
            with patch(
                "operator_harness.state.STATE_ROOT", Path(temporary_directory)
            ):
                checkpoint = build_checkpoint(
                    PROJECT,
                    objective="Ship the harness",
                    completed=["Created registry"],
                    next_action="Add close command",
                    now=now,
                )
                write_checkpoint(checkpoint)

                loaded = load_checkpoint(PROJECT["id"])

        self.assertEqual(loaded, checkpoint)
        self.assertEqual(loaded["status"], "active")

    def test_rejects_secret_like_text(self) -> None:
        with self.assertRaises(HarnessConfigError):
            build_checkpoint(
                PROJECT,
                objective="Use token " + "sk-" + "1234567890abcdefghijklmnop",
            )

    def test_close_writes_handoff_and_marks_checkpoint_closed(self) -> None:
        now = datetime(2026, 7, 21, 12, 0, tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as temporary_directory:
            with patch(
                "operator_harness.state.STATE_ROOT", Path(temporary_directory)
            ):
                checkpoint = build_checkpoint(
                    PROJECT,
                    objective="Ship the harness",
                    next_action="Review it",
                    now=now,
                )
                write_checkpoint(checkpoint)
                handoff = write_handoff(
                    {
                        "generated_at": now.isoformat(),
                        "project": PROJECT,
                        "checkpoint": checkpoint,
                        "effective_gates": ["tests"],
                        "workspace_changes": [],
                        "stray_documents": [],
                        "scope_leakage": [],
                        "writeback_proposals": [],
                    },
                    now=now,
                )
                closed = load_checkpoint(PROJECT["id"])

        self.assertTrue(handoff.name.endswith(".md"))
        self.assertEqual(closed["status"], "closed")


if __name__ == "__main__":
    unittest.main()
