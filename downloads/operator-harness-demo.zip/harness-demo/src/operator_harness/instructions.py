from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .model import merged_gates


MANAGED_MARKER = "<!-- operator-harness:managed:v1 -->"


@dataclass(frozen=True)
class InstructionPlan:
    path: Path
    status: str
    content: str

    def as_dict(self) -> dict[str, str]:
        return {"path": str(self.path), "status": self.status, "content": self.content}


def render_instruction_file(
    project: dict[str, Any], profile: dict[str, Any] | None, tool_name: str
) -> str:
    gates = merged_gates(project, profile)
    lines = [
        MANAGED_MARKER,
        f"# {project['name']} — {tool_name} Instructions",
        "",
        "This file is generated from the Pablo Operator Harness. Keep project-specific",
        "policy in the harness registry and regenerate this file instead of editing the",
        "managed content by hand.",
        "",
        "## Active contract",
        "",
        f"- Project: `{project['id']}`",
        f"- Organization: `{project['organization']}`",
        f"- Identity: `{project['identity']}`",
        f"- Profile: `{project['profile']}`",
        f"- Rigor level: `{project['level']}`",
        "- External actions: explicit approval required",
        "",
        "Start non-trivial work with `harness open .`. Use `harness checkpoint .`",
        "with an objective and next action during meaningful transitions, then run",
        "`harness close .` before handing off.",
        "",
        "## Sources of truth",
        "",
    ]
    for source in project.get("sources_of_truth", []):
        lines.append(f"- {source['name']}: `{source['location']}`")

    lines.extend(["", "## Artifact routes", ""])
    for artifact_type, destination in project.get("artifact_routes", {}).items():
        lines.append(f"- `{artifact_type}` → `{destination}`")

    lines.extend(["", "## Required gates", ""])
    lines.extend([f"- {gate}" for gate in gates])
    lines.extend(
        [
            "",
            "## Safety",
            "",
            "- Never store credentials or tokens in repository files or checkpoints.",
            "- Preserve existing user work and unrelated working-tree changes.",
            "- Do not send, publish, deploy, push, or mutate external systems without",
            "  explicit approval for that specific action.",
            "- Treat live code and services as newer than registry notes when they conflict;",
            "  report the drift and verify before acting.",
        ]
    )
    if project.get("organization") == "dasein":
        lines.extend(
            [
                "- Dasein durable knowledge belongs in `/Users/pabli/Dasein-Vault`; do not",
                "  use the historical workspace copy as the source of truth.",
            ]
        )
    return "\n".join(lines) + "\n"


def plan_instruction_sync(
    root: Path, project: dict[str, Any], profile: dict[str, Any] | None
) -> list[InstructionPlan]:
    plans: list[InstructionPlan] = []
    for filename, tool_name in (("AGENTS.md", "Agent"), ("CLAUDE.md", "Claude Code")):
        destination = root / filename
        content = render_instruction_file(project, profile, tool_name)
        if not destination.exists():
            status = "create"
        else:
            existing = destination.read_text(encoding="utf-8", errors="replace")
            if MANAGED_MARKER not in existing:
                status = "blocked_unmanaged"
            elif existing == content:
                status = "current"
            else:
                status = "update_managed"
        plans.append(InstructionPlan(destination, status, content))
    return plans


def apply_instruction_sync(plans: list[InstructionPlan]) -> list[InstructionPlan]:
    blocked = [plan for plan in plans if plan.status == "blocked_unmanaged"]
    if blocked:
        paths = ", ".join(str(plan.path) for plan in blocked)
        raise FileExistsError(f"Refusing to overwrite unmanaged instruction files: {paths}")

    for plan in plans:
        if plan.status in {"current"}:
            continue
        plan.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = plan.path.with_suffix(plan.path.suffix + ".tmp")
        temporary.write_text(plan.content, encoding="utf-8")
        temporary.replace(plan.path)
    return plans


def plans_as_json(plans: list[InstructionPlan]) -> str:
    return json.dumps([plan.as_dict() for plan in plans], indent=2, ensure_ascii=False)
