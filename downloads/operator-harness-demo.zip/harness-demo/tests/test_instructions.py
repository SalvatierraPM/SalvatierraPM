from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from operator_harness.instructions import (
    MANAGED_MARKER,
    apply_instruction_sync,
    plan_instruction_sync,
)


PROJECT = {
    "id": "example.project",
    "name": "Example Project",
    "organization": "personal",
    "identity": "pablo.personal",
    "profile": "personal-product",
    "level": 1,
    "sources_of_truth": [{"name": "Repo", "location": "."}],
    "artifact_routes": {"code": ".", "project_docs": "docs"},
    "gates": ["test_before_release"],
}
PROFILE = {"gates": ["record_product_direction"]}


class InstructionSyncTests(unittest.TestCase):
    def test_creates_and_recognizes_managed_instruction_files(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            plans = plan_instruction_sync(root, PROJECT, PROFILE)
            self.assertEqual({plan.status for plan in plans}, {"create"})

            apply_instruction_sync(plans)
            current = plan_instruction_sync(root, PROJECT, PROFILE)

        self.assertEqual({plan.status for plan in current}, {"current"})
        self.assertTrue(all(MANAGED_MARKER in plan.content for plan in current))

    def test_refuses_to_overwrite_unmanaged_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            (root / "AGENTS.md").write_text("# User instructions\n", encoding="utf-8")
            plans = plan_instruction_sync(root, PROJECT, PROFILE)

            with self.assertRaises(FileExistsError):
                apply_instruction_sync(plans)


if __name__ == "__main__":
    unittest.main()
